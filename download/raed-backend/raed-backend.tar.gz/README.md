# 🚀 رائد نيوم - Backend

محرك الذكاء الاصطناعي الصوتي المتقدم

## 🚀 النشر على Render

1. اذهب إلى [render.com](https://render.com)
2. اربط GitHub
3. أنشئ Web Service جديد
4. أضف متغير البيئة: `OPENAI_API_KEY`
5. انشر! ✅

## 🔌 Endpoints

| Endpoint | النوع | الوصف |
|----------|-------|-------|
| `GET /` | HTTP | حالة الخادم |
| `GET /health` | HTTP | فحص الصحة |
| `WS /media-stream` | WebSocket | Realtime Voice |
| `WS /ws` | WebSocket | محادثة نصية |

## 🐳 Docker

```bash
docker build -t raed-neom .
docker run -p 8000:8000 -e OPENAI_API_KEY=xxx raed-neom
```

## 📝 الترخيص

© 2025 جميع الحقوق محفوظة
